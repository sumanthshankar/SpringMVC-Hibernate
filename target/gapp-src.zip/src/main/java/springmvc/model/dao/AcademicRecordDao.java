package springmvc.model.dao;

import springmvc.model.AcademicRecord;

public interface AcademicRecordDao {

	
	AcademicRecord addAcademicRecord(AcademicRecord academicRecord);
	
}
