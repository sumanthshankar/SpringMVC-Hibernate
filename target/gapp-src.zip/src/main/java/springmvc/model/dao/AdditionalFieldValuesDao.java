package springmvc.model.dao;

import springmvc.model.AdditionalFieldValues;

public interface AdditionalFieldValuesDao {

	AdditionalFieldValues addAdditionalFieldValue(AdditionalFieldValues fieldValue);
	
}
