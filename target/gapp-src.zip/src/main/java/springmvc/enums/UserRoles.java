package springmvc.enums;

public enum UserRoles {

	admin,staff,student;
	
}
