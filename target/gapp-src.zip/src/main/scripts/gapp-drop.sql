drop table user_role cascade;

drop table users cascade;

drop table departments cascade;

drop table programs cascade;

drop table additional_fields cascade;

drop table student_information cascade;

drop table applications cascade;

drop table educational_background cascade;

drop table student_information_educational_background cascade;

drop table additional_field_values cascade;

drop table academic_record cascade;

drop table application_status cascade;

drop table application_status_update cascade;

drop table applications_additional_field_values cascade;

drop table applications_application_status_update cascade;

drop table users_student_information cascade;
