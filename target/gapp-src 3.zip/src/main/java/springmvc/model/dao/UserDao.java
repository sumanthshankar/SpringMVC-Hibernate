package springmvc.model.dao;

import java.util.List;

import springmvc.model.*;

public interface UserDao {

    AppUsers getUser( Integer id );

    List<AppUsers> getUsers();

}