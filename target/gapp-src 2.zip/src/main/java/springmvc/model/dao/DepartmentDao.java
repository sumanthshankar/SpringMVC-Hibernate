package springmvc.model.dao;

import java.util.List;

import springmvc.model.*;

public interface DepartmentDao {

	List<Departments> getDepartments();
	
}
